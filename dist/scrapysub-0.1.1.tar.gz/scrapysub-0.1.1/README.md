# ScrapySub

A simple web scraper that extracts text content from a given URL and its subpages.

## Installation

```sh
pip install ScrapySub
