# src/ScrapySub/__init__.py
from .scrape_web import ScrapeWeb
